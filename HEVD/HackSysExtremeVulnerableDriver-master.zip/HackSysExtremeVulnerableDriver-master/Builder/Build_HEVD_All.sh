#!/usr/bin/env bash

$(which sh) Build_HEVD_Secure_x64.sh
$(which sh) Build_HEVD_Vulnerable_x64.sh
